
public class GuitarAir implements Guitar {

	@Override
	public void play() {
		System.out.println("The guitarist plays a mad air guitar");
	}

}
