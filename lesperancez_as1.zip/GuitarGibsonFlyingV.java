
public class GuitarGibsonFlyingV implements Guitar {

	@Override
	public void play() {
		System.out.println("Some slick licks are played on the Flying V");
	}

}
