
public class GuitaristYoung extends Guitarist {

	@Override
	public String getName() {
		return "Angus Young";
	}

}
