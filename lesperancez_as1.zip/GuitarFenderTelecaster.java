
public class GuitarFenderTelecaster implements Guitar {

	@Override
	public void play() {
		System.out.println("The Telecaster says, \"Beedly Beedly Bwawow!\"");
	}

}
