
public class GuitarGibsonSG implements Guitar {

	@Override
	public void play() {
		System.out.println("A sick riff is played on the Gibson SG");
	}

}
