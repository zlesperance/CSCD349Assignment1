
public class GuitaristHendrix extends Guitarist {

	@Override
	public String getName() {
		return "Jimi Hendrix";
	}

}
