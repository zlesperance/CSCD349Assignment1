
public interface Guitar {
	public void play();
}
