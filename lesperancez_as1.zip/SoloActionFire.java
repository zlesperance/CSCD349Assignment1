
public class SoloActionFire implements SoloAction {

	@Override
	public void perform() {
		System.out.println("The guitarist sets the guitar on fire! Goodness gracious! Great balls of fire!");
	}

}
