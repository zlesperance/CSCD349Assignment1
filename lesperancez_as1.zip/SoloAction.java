
public interface SoloAction {
	public abstract void perform();
}
