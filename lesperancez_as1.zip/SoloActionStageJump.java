
public class SoloActionStageJump implements SoloAction {

	@Override
	public void perform() {
		System.out.println("The guitarist leaps off of the stage and into the crowd!");
	}

}
