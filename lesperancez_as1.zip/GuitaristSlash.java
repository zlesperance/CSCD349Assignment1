
public class GuitaristSlash extends Guitarist {

	@Override
	public String getName() {
		return "Slash";
	}

}
