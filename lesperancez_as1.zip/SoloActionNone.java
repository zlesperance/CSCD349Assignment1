
public class SoloActionNone implements SoloAction {

	@Override
	public void perform() {
		System.out.println("The guitarist does nothing spectacular");
	}

}
