
public class SoloActionSmash implements SoloAction {

	@Override
	public void perform() {
		System.out.println("CRASH!! The guitarist smashes the guitar!");
	}

}
